<div class="footery">
	<div class="footer-content">
		<ul class="list-inline list-unstyled navbar-footer">
			<li>Copyright &copy; <?php echo date('Y'); ?> <?php echo IN_NAME; ?> .All Rights Reserved.</li>
			<li><a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo IN_QQ; ?>&site=qq&menu=yes"  target="_blank">举报该应用</a></li>
			<li><a href="http://www.miitbeian.gov.cn/" target="_blank"><?php echo IN_ICP; ?></a></li>
          	<li>声明：本平台仅供应用内测使用，请勿上传非法应用。如违规违法上传应用一切后果有上传者承担。</li>
			<li><?php echo base64_decode(IN_STAT); ?></li>
		</ul>
	</div>
</div>