<!DOCTYPE html>
<html lang="zh-cn">
<head>
<meta charset="<?php echo IN_CHARSET; ?>">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=0">
<meta name="keywords" content="<?php echo IN_KEYWORDS; ?>">
<meta name="description" content="<?php echo IN_DESCRIPTION; ?>">
<title><?php echo $hjtitle;?> - <?php echo IN_NAME; ?></title>
<link href="<?php echo IN_PATH; ?>static/app/download.css" rel="stylesheet">
<link href="<?php echo IN_PATH; ?>static/guide/swiper-3.3.1.min.css" rel="stylesheet">
<link href="<?php echo IN_PATH; ?>static/guide/ab.css" rel="stylesheet">
<style type="text/css">.wechat_tip,.wechat_tip>i{position:absolute;right:10px}.wechat_tip{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;background:#3ab2a7;color:#fff;font-size:14px;font-weight:500;width:135px;height:60px;border-radius:10px;top:15px}.wechat_tip>i{top:-10px;width:0;height:0;border-left:6px solid transparent;border-right:6px solid transparent;border-bottom:12px solid #3ab2a7}.mask img{max-width:100%;height:auto}</style>
<script src="<?php echo IN_PATH; ?>static/guide/zepto.min.js" type="text/javascript"></script>
<script src="<?php echo IN_PATH; ?>static/guide/swiper.jquery.min.js" type="text/javascript"></script>
<style type="text/css">.wechat_tip,.wechat_tip>i{position:absolute;right:10px}.wechat_tip{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;background:#3ab2a7;color:#fff;font-size:14px;font-weight:500;width:135px;height:60px;border-radius:10px;top:15px}.wechat_tip>i{top:-10px;width:0;height:0;border-left:6px solid transparent;border-right:6px solid transparent;border-bottom:12px solid #3ab2a7}.mask img{max-width:100%;height:auto}
</style>

<!--开始-->
<style type="text/css">
	*,:after,:before{margin:0;padding:0;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}[class*='grid-']{float:left;padding:10px;width:100%}.clear-grid{clear:both;float:inherit}.container{margin:0;width:100%}.container:after,.container:before{display:table;clear:both;content:" "}.nest{margin:0 -10px;padding:0;width:auto}.grid-m-12{width:100%}.grid-m-11{width:91.666663%}.grid-m-10{width:83.33%}.grid-m-9{width:74.999997%}.grid-m-8{width:66.66666664%}.grid-m-7{width:58.333%}.grid-m-6{width:50%}.grid-m-5{width:41.6665%}.grid-m-4{width:33.33%}.grid-m-3{width:24.99%}.grid-m-2{width:16.66666%}.grid-m-1{width:8.33%}@media (min-width: 720px){.grid-12{width:100%}.grid-11{width:91.666663%}.grid-10{width:83.33%}.grid-9{width:74.999997%}.grid-8{width:66.66666664%}.grid-7{width:58.333%}.grid-6{width:30%}.grid-5{width:41.6665%}.grid-4{width:33.33%}.grid-3{width:24.99%}.grid-2{width:16.66666%}.grid-1{width:8.33%}.grid-t-12{width:100%}.grid-t-11{width:91.666663%}.grid-t-10{width:83.33%}.grid-t-9{width:74.999997%}.grid-t-8{width:66.66666664%}.grid-t-7{width:58.333%}.grid-t-6{width:50%}.grid-t-5{width:41.6665%}.grid-t-4{width:33.33%}.grid-t-3{width:24.99%}.grid-t-2{width:16.66666%}.grid-t-1{width:8.33%}}@media only screen and (min-width: 1024px){.grid-tl-12{width:100%}.grid-tl-11{width:91.666663%}.grid-tl-10{width:83.33%}.grid-tl-9{width:74.999997%}.grid-tl-8{width:66.66666664%}.grid-tl-7{width:58.333%}.grid-tl-6{width:50%}.grid-tl-5{width:41.6665%}.grid-tl-4{width:33.33%}.grid-tl-3{width:24.99%}.grid-tl-2{width:16.66666%}.grid-tl-1{width:8.33%}}@media only screen and (min-width: 1200px){.container{max-width:1180px;margin:0 auto}.container-fluid{max-width:90%;margin:0 5%}.grid-d-12{width:100%}.grid-d-11{width:91.666663%}.grid-d-10{width:83.33%}.grid-d-9{width:74.999997%}.grid-d-8{width:66.66666664%}.grid-d-7{width:58.333%}.grid-d-6{width:50%}.grid-d-5{width:41.6665%}.grid-d-4{width:33.33%}.grid-d-3{width:24.99%}.grid-d-2{width:16.66666%}.grid-d-1{width:8.33%}}img.scale,img.responsive{max-width:100%;height:auto}
	</style>
<style type="text/css">
  	html {font-family: "Microsoft YaHei";-webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%;}
  	body {margin: 0;}
  	img{max-width:100%;}
  	a{text-decoration:none;}
  	.weixin-tip{display: none; position: fixed; left:0; top:0; bottom:0; background: rgba(0,0,0,0.8); filter:alpha(opacity=80); height: 100%; width: 100%; z-index: 100;}
	.weixin-tip p{text-align: center; margin-top: 10%; padding:0 5%;}
	.text-center{text-align:center;}
	.text-left{text-align:left;}
	.btn {display: inline-block;padding: 6px 16px;margin-bottom: 0;font-size: 14px;font-weight: normal;line-height: 1.42857143;text-align: center;white-space: nowrap;vertical-align: middle;-ms-touch-action: manipulation;touch-action: manipulation;cursor: pointer;-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;background-image: none;border: 1px solid transparent;border-radius: 1px;}
	.btn:focus,.btn:active:focus,.btn.active:focus,.btn.focus,.btn:active.focus,.btn.active.focus {outline: thin dotted;outline: 5px auto -webkit-focus-ring-color;outline-offset: -2px;}
	.btn:hover,.btn:focus,.btn.focus {color: #333;text-decoration: none;}
	.btn:active,.btn.active {background-image: none;outline: 0;-webkit-box-shadow: inset 0 3px 5px rgba(0, 0, 0, .125);box-shadow: inset 0 3px 5px rgba(0, 0, 0, .125);}
	.btn.disabled,.btn[disabled],fieldset[disabled] .btn {cursor: not-allowed;filter: alpha(opacity=65); -webkit-box-shadow: none;box-shadow: none;opacity: .65;color:gray;}
	a.btn.disabled,fieldset[disabled] a.btn {pointer-events: none;}
	.btn-warn {color: #fff;background-color: red;border-color: red;width:100%;margin:15px 0;}
	.btn-warn2 {color: #fff;background-color: #0066ff;border-color: #0066ff;width:100%;margin:15px 0;}
	.btn-warn3 {color: #fff;background-color: #000000;border-color: #000000;width:100%;margin:15px 0;}
	.btn-primary {color: #fff;background-color: #0066ff;border-color: #27a28b;width:100%;margin:15px 0;}
	.btn-primary:focus,.btn-primary.focus {color: #fff;background-color: #27a28b;border-color: #27a28b;}
	.btn-primary:hover {color: #fff;background-color: #27a28b;border-color: #27a28b;}
	.btn-primary:active,.btn-primary.active{color: #fff;background-color: #27a28b;border-color: #27a28b;}
	.btn-success {color: #fff;background-color: #0a661d;border-color: #0a661d;}
	.btn-success:hover {color: #fff;background-color: #0a661d;border-color: #0a661d;}
	/*.btn-lg,.btn-group-lg > .btn {padding: 10px 25px;font-size: 18px;line-height: 1.3333333;border-radius: 4px;}*/
	.btn-lg,.btn-group-lg > .btn {padding: 10px 25px;font: normal 100% Helvetica, Arial, sans-serif; line-height: 1.3333333;border-radius: 4px;width: 100%;height: 40px;}
	.btn-xs,.btn-group-xs > .btn {padding: 1px 5px;line-height: 1.3333333;border-radius: 3px;}
	.text-muted {color: #777;font-size:14px;}
	.mg-5{margin:5px;}
	.mgt-5{margin-top:5px;}
	.mgb-5{margin-bottom:5px;}
	.mgl-5{margin-left:5px;}
	.mgr-5{margin-right:5px;}
	.mg-10{margin:10px;}
	.mgt-10{margin-top:10px;}
	.mgb-10{margin-bottom:10px;}
	.mgl-10{margin-left:10px;}
	.mgr-10{margin-right:10px;}
	.mg-15{margin:15px;}
	.mgt-15{margin-top:15px;}
	.mgb-15{margin-bottom:15px;}
	.mgl-15{margin-left:15px;}
	.mgr-15{margin-right:15px;}
	.mg-20{margin:20px;}
	.mgt-20{margin-top:20px;}
	.mgb-20{margin-bottom:20px;}
	.mgl-20{margin-left:20px;}
	.mgr-20{margin-right:20px;}
	.mgt-30{margin-top:30px;}
	.pdt-5{margin-top:5px;}
	.pdb-5{margin-bottom:5px;}
	.pdl-5{margin-left:5px;}
	.pdr-5{margin-right:5px;}
	.pdt-10{margin-top:10px;}
	.pdb-10{margin-bottom:10px;}
	.pdl-10{margin-left:10px;}
	.pdr-10{margin-right:10px;}
	.pdt-15{margin-top:15px;}
	.pdb-15{margin-bottom:15px;}
	.pdl-15{margin-left:15px;}
	.pdr-15{margin-right:15px;}
	.info{color: #777;margin:0 5px;font-size:14px;}
	.input-group{height:40px;}
	.input{border:1px solid #ccc;height:100%;line-height:30px;color:red;font-weight:bold;padding: 2px 16px;font-size:16px;width:120px;}
	
	footer{background:#000;margin-top:10px;color:#fff;line-height:30px;font-size:13px;filter:alpha(opacity=80);-moz-opacity:0.8;  -khtml-opacity: 0.8;  opacity: 0.8;padding-top:10px;padding-bottom:20px;}
    footer a{color:#2bad95;margin:0px 5px 0 5px;}
    
    .box{position: fixed;z-index:999; width: 100%; height: 100%;left:0;top:0; background: rgba(0,0,0,0.2); display: none;}  
    .box-content{background:#fff;padding:1em 2em;width:500px;max-width:90%; position: relative;left: 50%; top: 25%; margin-left: -250px;border: 1px solid #000000;}  
  	.right{position:absolute;right:1em;top:0.5em;cursor:pointer;}
  	@media only screen and (max-width: 640px) {
  		.box-content{width:80%;margin-left:0;left:10%;}
  	}
  </style>
</head>
<body>
<span class="pattern left"><img src="<?php echo IN_PATH; ?>static/app/left.png"></span>
<span class="pattern right"><img src="<?php echo IN_PATH; ?>static/app/right.png"></span>
<div class="out-container">
	<div class="main">
		<header>
		<div class="table-container">
			<div class="cell-container">
		
				<!--开始-->		
				
				<div id="content-wrapper" class="container" style="min-height: 1080px;">
		<div class="container text-center" style="line-height:30px;"></div>
		<div class="container">
			<div class="grid-3"></div>
			<div class="grid-6 text-center">
              <h2 class="text-center" style="line-height:60px;border-radius: 100px;">
                
                <img src="<?php if($imgUrlnew==null||$imgUrlnew==''){ echo $imgUrl ; }else{ echo $imgUrlnew;}?>" width="100">

              </h2>
               <h2 class="text-center" style="line-height:20px;border-radius: 100px;">
                
                <?php echo $hjtitle;?>

              </h2>
              <?php if($urlArray[0]['c1']!=''&&$urlArray[0]['c1']!=null&&$urlArray[0]['n1']!=''&&$urlArray[0]['n1']!=null){ ?>
             
                	<div>
					<a class="btn btn-primary btn-lg" href="<?php echo $urlArray[0]['c1']; ?>" target="_blank"><?php echo $urlArray[0]['n1']; ?> </a>
				</div>	
                <?php } ?>
              
              	<?php echo $c1; ?>
              <?php if($urlArray[0]['c2']!=''&&$urlArray[0]['c2']!=null&&$urlArray[0]['n2']!=''&&$urlArray[0]['n2']!=null){ ?>
             
                	<div>
					<a class="btn btn-primary btn-lg" href="<?php echo $urlArray[0]['c2']; ?>" target="_blank"><?php echo $urlArray[0]['n2']; ?> </a>
				</div>	
                <?php } ?>
              
              
              
              <?php
 $num=1;
foreach ($result as $obj) {
?>
				
				<div>
					<a class="btn btn-primary btn-lg" href="<?php echo getlink($obj['in_id']); ?>" target="_blank"><?php echo $obj['in_name']; ?>&nbsp;&nbsp;  点击安装</a>
				</div>	
<?php
$num+=1;
                          }
?>	
				
				<div >
                
                <?php echo $hjcontext;?>
                  </div>	
							
		</div>
		</div>
			<div class="footer"><?php echo $_SERVER['HTTP_HOST']; ?> 是应用内测平台，请自行甄别应用风险！如有问题可通过邮件反馈。<a class="one-key-report" href="mailto:<?php echo IN_MAIL; ?>">联系我们</a></div>
	</div>
</div>
<div class="mask" style="display:none"></div>
</body>
</html>