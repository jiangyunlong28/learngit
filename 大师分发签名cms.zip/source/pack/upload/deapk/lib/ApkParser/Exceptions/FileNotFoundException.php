<?php
namespace ApkParser\Exceptions;

class FileNotFoundException extends ApkException
{

}