<?php
namespace ApkParser\Exceptions;

class ApkException extends \Exception
{

}