<?php
namespace ApkParser\Exceptions;

class StreamNotFoundException extends ApkException
{

}